# Sishir Shrestha — Student Portfolio

A responsive portfolio website inspired by the section layout of the reference portfolio shared by the user. It has been personalized for Sishir's Integrated Business Management studies and data analytics career goal.

## Included files
- `index.html` — full responsive website, with CSS and a small JavaScript mobile navigation menu
- `README.md` — setup and deployment instructions

## Before publishing
- Replace `https://github.com/` placeholders with your actual GitHub profile or project repository URLs.
- Replace `your.email@example.com` with an email address you are comfortable publishing.
- Keep project status accurate. Some project cards are learning/planned projects; update descriptions when you complete them.

## Publish with GitHub Pages
1. Create a repository on GitHub.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, then select `main` and `/(root)`.
5. Save and wait for the published website URL to appear.

For a personal site, the repository can be named `YOUR-USERNAME.github.io`. For a project site, use the repository's Pages URL shown in Settings → Pages.
